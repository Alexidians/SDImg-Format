import argparse
import json
import zlib
import base64
from PIL import Image

# Function to convert PNG to SDIMG format
def png_to_sdimg(input_png, output_sdimg, compression_level=9, color_type="rgba"):
    # Open PNG image
    img = Image.open(input_png)
    width, height = img.size
    pixels = img.load()

    # Prepare pixel data in the desired format (either RGB or HEX)
    pixel_data = {}
    for y in range(height):
        for x in range(width):
            # Extract RGBA or RGB based on image mode
            pixel = img.getpixel((x, y))
            if len(pixel) == 4:  # RGBA image
                r, g, b, a = pixel
            elif len(pixel) == 3:  # RGB image, no alpha channel
                r, g, b = pixel
                a = 255  # Default alpha to 255 (fully opaque)

            if color_type == "hex":
                # Convert RGBA to hex format
                hex_value = f"#{r:02x}{g:02x}{b:02x}{a:02x}"
                pixel_data[f"{x+1}x{y+1}"] = {"hex": hex_value}
            else:
                # Use RGBA format
                pixel_data[f"{x+1}x{y+1}"] = {"r": r, "g": g, "b": b, "a": a}

    # Construct the JSON structure
    image_data = {
        "colortype": color_type,
        "comp_level": compression_level,
        "pixels": pixel_data,
        "width": width,
        "height": height
    }

    # Convert to JSON and compress
    json_data = json.dumps(image_data)
    compressed_data = zlib.compress(json_data.encode('utf-8'), level=compression_level)

    # Base64 encode the compressed data and write to file
    base64_encoded = base64.b64encode(compressed_data).decode('utf-8')
    with open(output_sdimg, 'w') as f:
        f.write(base64_encoded)

    print(f"Image saved as {output_sdimg} with compression level {compression_level}")

# Function to convert SDIMG back to PNG format
def sdimg_to_png(input_sdimg, output_png):
    # Read the SDIMG file and decode base64 data
    with open(input_sdimg, 'r') as f:
        base64_encoded_data = f.read()

    # Decode base64 and decompress
    compressed_data = base64.b64decode(base64_encoded_data)
    json_data = zlib.decompress(compressed_data).decode('utf-8')

    # Parse the JSON data
    image_data = json.loads(json_data)

    # Extract pixel data and metadata
    width = image_data['width']
    height = image_data['height']
    color_type = image_data['colortype']
    pixels = image_data['pixels']

    # Create a new image
    img = Image.new("RGBA", (width, height))

    # Set the pixel data
    for y in range(height):
        for x in range(width):
            pixel_key = f"{x+1}x{y+1}"
            if color_type == "hex":
                hex_value = pixels[pixel_key]["hex"]
                img.putpixel((x, y), tuple(int(hex_value[i:i+2], 16) for i in (1, 3, 5, 7)))
            else:
                r = pixels[pixel_key]["r"]
                g = pixels[pixel_key]["g"]
                b = pixels[pixel_key]["b"]
                a = pixels[pixel_key]["a"]
                img.putpixel((x, y), (r, g, b, a))

    # Save the image as PNG
    img.save(output_png, "PNG")
    print(f"Image saved as {output_png}")

# Command-line interface setup
def main():
    parser = argparse.ArgumentParser(description="Convert PNG to SDIMG and vice versa.")
    
    subparsers = parser.add_subparsers(dest="command")

    # Subcommand for converting PNG to SDIMG
    png_to_sdimg_parser = subparsers.add_parser("png-to-sdimg", help="Convert PNG to SDIMG format.")
    png_to_sdimg_parser.add_argument("input_png", help="Input PNG file path")
    png_to_sdimg_parser.add_argument("output_sdimg", help="Output SDIMG file path")
    png_to_sdimg_parser.add_argument("--compression", type=int, default=9, help="Compression level (0-9)")
    png_to_sdimg_parser.add_argument("--colortype", choices=["rgba", "hex"], default="rgba", help="Color format")

    # Subcommand for converting SDIMG to PNG
    sdimg_to_png_parser = subparsers.add_parser("sdimg-to-png", help="Convert SDIMG to PNG format.")
    sdimg_to_png_parser.add_argument("input_sdimg", help="Input SDIMG file path")
    sdimg_to_png_parser.add_argument("output_png", help="Output PNG file path")

    args = parser.parse_args()

    # Execute appropriate function based on subcommand
    if args.command == "png-to-sdimg":
        png_to_sdimg(args.input_png, args.output_sdimg, args.compression, args.colortype)
    elif args.command == "sdimg-to-png":
        sdimg_to_png(args.input_sdimg, args.output_png)
    else:
        print("Unknown command.")

if __name__ == "__main__":
    main()
