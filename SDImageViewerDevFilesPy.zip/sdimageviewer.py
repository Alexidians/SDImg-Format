import os
import sys
import hashlib
import subprocess
import json
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QCheckBox, QDialog, QDialogButtonBox, QLabel, QPushButton
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt

SETTINGS_FILE = "settings.json"
CACHE_DIR = "cache"

# Load settings from JSON file
def load_settings():
    if os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE, 'r') as file:
            return json.load(file)
    else:
        # Default settings
        return {
            "use_cache": False,
            "use_default_viewer": False,
        }

# Save settings to JSON file
def save_settings(settings):
    with open(SETTINGS_FILE, 'w') as file:
        json.dump(settings, file, indent=4)

def get_file_hash(file_path):
    """Generate a content hash for the file."""
    hash_sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        while chunk := f.read(8192):
            hash_sha256.update(chunk)
    return hash_sha256.hexdigest()

class SettingsPopup(QDialog):
    def __init__(self, settings):
        super().__init__()
        self.setWindowTitle("Settings")
        self.setFixedSize(300, 150)
        
        self.cache_checkbox = QCheckBox("Conversion Caching", self)
        self.cache_checkbox.setChecked(settings.get("use_cache", False))
        
        self.viewer_checkbox = QCheckBox("Use Default Photo Viewer", self)
        self.viewer_checkbox.setChecked(settings.get("use_default_viewer", False))
        
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        
        layout = QVBoxLayout()
        layout.addWidget(self.cache_checkbox)
        layout.addWidget(self.viewer_checkbox)
        layout.addWidget(buttons)
        
        self.setLayout(layout)
        
    def get_settings(self):
        return {
            "use_cache": self.cache_checkbox.isChecked(),
            "use_default_viewer": self.viewer_checkbox.isChecked(),
        }

class SDImageViewer(QWidget):
    def __init__(self, file_path=None):
        super().__init__()
        self.setWindowTitle("SDImage Viewer")
        self.setFixedSize(600, 400)
        
        layout = QVBoxLayout()
        
        self.image_label = QLabel(self)
        self.image_label.setAlignment(Qt.AlignCenter)  # Center the image in the QLabel
        
        self.settings_button = QPushButton("Settings", self)
        self.settings_button.clicked.connect(self.show_settings)
        
        layout.addWidget(self.image_label)
        layout.addWidget(self.settings_button)
        
        self.setLayout(layout)
        
        self.settings = load_settings()  # Load saved settings
        self.file_path = file_path
        
        if self.file_path:
            self.load_image()

    def show_settings(self):
        settings_popup = SettingsPopup(self.settings)
        if settings_popup.exec_() == QDialog.Accepted:
            self.settings = settings_popup.get_settings()
            save_settings(self.settings)  # Save settings after change
        
    def load_image(self):
        if self.file_path:
            png_file_path = self.convert_sdimg_to_png(self.file_path)
            
            if self.settings["use_default_viewer"]:
                self.open_in_default_viewer(png_file_path)
            else:
                self.display_image(png_file_path)
                
    def convert_sdimg_to_png(self, sdimg_path):
        file_hash = get_file_hash(sdimg_path)
        cache_png_path = os.path.join(CACHE_DIR, f"{file_hash}.png")
        
        # If cache exists and caching is enabled, load the cached image
        if self.settings["use_cache"] and os.path.exists(cache_png_path):
            return cache_png_path
        
        # Otherwise, convert and save to cache
        if not os.path.exists(CACHE_DIR):
            os.makedirs(CACHE_DIR)

        subprocess.run(["sdimgtools.exe", "sdimg-to-png", sdimg_path, cache_png_path])
        return cache_png_path
        
    def display_image(self, png_path):
        pixmap = QPixmap(png_path)
        self.image_label.setPixmap(pixmap)
        self.image_label.setScaledContents(True)  # Allow the image to scale to the size of the QLabel
        
    def open_in_default_viewer(self, png_path):
        subprocess.run(["start", png_path], shell=True)
        
    def clean_up_cache(self, png_path):
        if not self.settings["use_cache"]:
            os.remove(png_path)

def main():
    app = QApplication(sys.argv)
    
    if len(sys.argv) != 2:
        print("Usage: python SDImageViewer.py <file_path>")
        sys.exit()

    file_path = sys.argv[1]

    if file_path.endswith(".sdimg"):
        viewer = SDImageViewer(file_path)
        viewer.show()
        sys.exit(app.exec_())
    else:
        print("Unsupported file format!")
        sys.exit()

if __name__ == "__main__":
    main()
